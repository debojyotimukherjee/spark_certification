# join iowa_houses, with iowa_houses_other_features
# join on Id  
# return Id, LotArea, LotConfig from iowa_houses
# return Id, Other_Features, Airbnb_Flag from iowa_houses_other_features
# filter on other_features = basketball hoop, sort on LotArea descending
# save in folder

from pyspark import SparkContext, SparkConf
conf = SparkConf().setMaster("local").setAppName("task7")
sc = SparkContext(conf=conf)
from pyspark.sql import SQLContext
sqlContext = SQLContext(sc)
from pyspark.sql.types import *


def parseLines1(file1):
	fields1 = file1.split(",")
	Id = int(fields1[0])
	LotArea = float(fields1[4])
	LotConfig = str(fields1[10])
	return Id, LotArea, LotConfig
	
file1 = sc.textFile("file:///spark_practice/iowa_houses.csv")
line1 = file1.map(parseLines1)
schema1 = StructType([   \
StructField('Id', IntegerType(), True), \
StructField('LotArea', FloatType(), True), \
StructField('LotConfig', StringType(), True)   \
])

df1 = sqlContext.createDataFrame(line1, schema1)
df1.registerTempTable("iowa_houses_7")

def parseLines2(file2):
	fields2 = file2.split(",")
	Id = int(fields2[0])
	Other_Features = str(fields2[1])
	Airbnb_Flag = int(fields2[2])
	return Id, Other_Features, Airbnb_Flag
	
file2 = sc.textFile("file:///spark_practice/iowa_houses_other_features.csv")
line2 = file2.map(parseLines2)

schema2 = StructType([   \
StructField('Id', IntegerType(), True), \
StructField('Other_Features', StringType(), True), \
StructField('Airbnb_Flag', IntegerType(), True)   \
])

df2 = sqlContext.createDataFrame(line2, schema2)
df2.registerTempTable("iowa_houses_other_features_7")

answer = sqlContext.sql("select ih.Id, ih.LotArea, ih.LotConfig, of.Other_Features, of.Airbnb_Flag   \
from iowa_houses_7 ih left join iowa_houses_other_features_7 of  on  \
ih.Id = of.Id    \
where of.Other_Features = 'basketball hoop'   \
order by ih.LotArea desc")

 
answer.rdd.map(lambda x: "\t".join(map(str,x))).coalesce(1).saveAsTextFile("file:///spark_practice/solutions/task7") 