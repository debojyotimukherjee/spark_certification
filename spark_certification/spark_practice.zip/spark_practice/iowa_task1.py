## 1.	Read a comma separated file from hdfs, select 7 of the more than 20 columns, filter, sort, save back to hdfs   

## show Id, LotFrontage, BsmtFinType2, RoofStyle
## filter Roofstyle = 'Gable'
## order by Lotfrontage with highest being first


from pyspark import SparkContext, SparkConf
conf = SparkConf().setMaster("local").setAppName("task1")
sc = SparkContext(conf=conf)
from pyspark.sql import SQLContext
sqlContext = SQLContext(sc)
from pyspark.sql.types import *


def parseLines1(file1):
	fields = file1.split(",")
	Id = int(fields[0])
	LotFrontage = float(fields[3])
	BsmtFinType2 = str(fields[35])
	RoofStyle = str(fields[21])
	return Id, LotFrontage, BsmtFinType2, RoofStyle
	
file1 = sc.textFile("file:///spark_practice/iowa_houses.csv")
line1 = file1.map(parseLines1)
schema1 = StructType([      \
StructField('Id', IntegerType(), True), \
StructField('LotFrontage', FloatType(), True), \
StructField('BsmtFinType2', StringType(), True),  \
StructField('Roofstyle', StringType(), True)  \
])

df1 = sqlContext.createDataFrame(line1, schema1)
df1.registerTempTable("iowa_houses_1")


answer = sqlContext.sql("select Id, LotFrontage, BsmtFinType2, Roofstyle \
from iowa_houses_1f where Roofstyle = 'Gable' \
order by LotFrontage desc ")


answer.rdd.map(lambda x: ",".join(map(str,x))).coalesce(1).saveAsTextFile("file:///spark_practice/solutions/task1")


