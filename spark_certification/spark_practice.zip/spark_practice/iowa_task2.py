## 2.	Read a json file from hdfs, select 7 of the more than 20 columns, filter, sort, save back to hdfs   

## show Id, MasVnrArea, YearBuilt, Utilities columns
# filter on YearBuilt  > 2006
# order by MasVnrArea from largest to smallest

from pyspark import SparkContext, SparkConf
conf = SparkConf().setMaster("local").setAppName("task2")
sc = SparkContext(conf=conf)
from pyspark.sql import SQLContext
sqlContext = SQLContext(sc)
from pyspark.sql.types import *

df = sqlContext.read.json("file:///spark_practice/json_iowa_houses")
df.registerTempTable("iowa_houses_2e")


answer = sqlContext.sql("select cast(Id as int), cast(MasVnrArea as float), cast(YearBuilt as int), Utilities \
from iowa_houses_2e    \
where cast(YearBuilt as int) <= 2006   \
order by cast(MasVnrArea as float) desc ") 

answer.rdd.map(lambda x: "\t".join(map(str,x))).coalesce(1).saveAsTextFile("file:///spark_practice/solutions/task2")

# if wanted to save it to a json file
#answer.write.save("file:///spark_practice/solutions/task2_json", format='json')