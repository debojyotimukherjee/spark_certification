# use an accumulator to count how many rows have ERROR in them 


from pyspark import SparkContext, SparkConf
conf = SparkConf().setMaster("local").setAppName("task5_Ld")
sc = SparkContext(conf=conf)

accum = sc.accumulator(0)

file = sc.textFile("file:///spark_practice/log_files/*")
lines = file.map(lambda x: x.split("\t"))

error_data = lines.filter(lambda x: "error" in x[0])
error_count = error_data.foreach(lambda x: accum.add(1))

print(accum.value)