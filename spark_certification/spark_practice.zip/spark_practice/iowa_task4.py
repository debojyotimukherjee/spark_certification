## querying the hive tables, apply aggregate functionalities, conditions and ordering.

# cannot connect to hive. this is fake data. working with years here

# find out the avg of houses bought in the year 2012 per zip code. order by zip code with highest avg amount bought 
# all data is in string format


from pyspark import SparkContext, SparkConf
conf = SparkConf().setMaster("local").setAppName("task4")
sc = SparkContext(conf=conf)
from pyspark.sql import HiveContext
sqlContext = HiveContext(sc)
from pyspark.sql.types import *


answer = sqlContext.sql("select  avg(cast(amount as float)), cast(zip_code as int),  \
year(to_date(from_unixtime(unix_timestamp(purchase_date, 'yyyy-MM-dd')))) as yr  \
from iowa_houses   \
where year(to_date(from_unixtime(unix_timestamp(purchase_date, 'MMddyyyy')))) = '2012'  \
group by zip_code \
order by avg(cast(amount as float)) ")


answer.rdd.map(lambda x: "\t".join(map(str,x))).coalesce(1).saveAsTextFile("file:///spark_practice/solutions/task4")


#'yyyy-MM-dd'   <---- this part mirrors the string format of the date you're trying to convert to date format