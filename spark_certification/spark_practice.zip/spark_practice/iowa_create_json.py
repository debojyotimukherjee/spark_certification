## 1.	Read a comma separated file from hdfs, select 7 of the more than 20 columns, filter, sort, save back to hdfs   

## show Id, Alley, TotalBsmtSF columns
# filter on Alley = 'Grvl'
# filter by TotalBsmtSF showing highest amounts

from pyspark import SparkContext, SparkConf
conf = SparkConf().setMaster("local").setAppName("taskNA")
sc = SparkContext(conf=conf)
from pyspark.sql import SQLContext
sqlContext = SQLContext(sc)
from pyspark.sql.types import *


line = sc.textFile("file:///spark_practice/iowa_houses.csv")

def parseLines(line):
	fields = line.split(",")
	Id = fields[0]
        MSSubClass = fields[1]
        MSZoning = fields[2]
        LotFrontage = fields[3]
        LotArea = fields[4]
        Street = fields[5]
        Alley = fields[6]
        LotShape = fields[7]
        LandContour = fields[8]
        Utilities = fields[9]
        LotConfig = fields[10]
        LandSlope = fields[11]
        Neighborhood = fields[12]
        Condition1 = fields[13]
        Condition2 = fields[14]
        BldgType = fields[15]
        HouseStyle = fields[16]
        OverallQual = fields[17]
        OverallCond = fields[18]
        YearBuilt = fields[19]
        YearRemodAdd = fields[20]
        RoofStyle = fields[21]
        RoofMatl = fields[22]
        Exterior1st = fields[23]
        Exterior2nd = fields[24]
        MasVnrType = fields[25]
        MasVnrArea = fields[26]
        ExterQual = fields[27]
        ExterCond = fields[28]
        Foundation = fields[29]
        BsmtQual = fields[30]
        BsmtCond = fields[31]
        BsmtExposure = fields[32]
        BsmtFinType1 = fields[33]
        BsmtFinSF1 = fields[34]
        BsmtFinType2 = fields[35]
        BsmtFinSF2 = fields[36]
        BsmtUnfSF = fields[37]
        TotalBsmtSF = fields[38]
        Heating = fields[39]
        HeatingQC = fields[40]
        CentralAir = fields[41]
        Electrical = fields[42]
        FirstFlrSF = fields[43]
        SecondFlrSF = fields[44]
        LowQualFinSF = fields[45]
        GrLivArea = fields[46]
        BsmtFullBath = fields[47]
        BsmtHalfBath = fields[48]
        FullBath = fields[49]
        HalfBath = fields[50]
        BedroomAbvGr = fields[51]
        KitchenAbvGr = fields[52]
        KitchenQual = fields[53]
        TotRmsAbvGrd = fields[54]
        Functional = fields[55]
        Fireplaces = fields[56]
        FireplaceQu = fields[57]
        GarageType = fields[58]
        GarageYrBlt = fields[59]
        GarageFinish = fields[60]
        GarageCars = fields[61]
        GarageArea = fields[62]
        GarageQual = fields[63]
        GarageCond = fields[64]
        PavedDrive = fields[65]
        WoodDeckSF = fields[66]
        OpenPorchSF = fields[67]
        EnclosedPorch = fields[68]
        ThirdSsnPorch = fields[69]
        ScreenPorch = fields[70]
        PoolArea = fields[71]
        PoolQC = fields[72]
        Fence = fields[73]
        MiscFeature = fields[74]
        MiscVal = fields[75]
        MoSold = fields[76]
        YrSold = fields[77]
        SaleType = fields[78]
        SaleCondition = fields[79]

	return (Id,MSSubClass, MSZoning, LotFrontage, LotArea, Street, Alley, LotShape, LandContour, Utilities,
LotConfig,
LandSlope,
Neighborhood,
Condition1,
Condition2,
BldgType,
HouseStyle,
OverallQual,
OverallCond,
YearBuilt,
YearRemodAdd,
RoofStyle,
RoofMatl,
Exterior1st,
Exterior2nd,
MasVnrType,
MasVnrArea,
ExterQual,
ExterCond,
Foundation,
BsmtQual,
BsmtCond,
BsmtExposure,
BsmtFinType1,
BsmtFinSF1,
BsmtFinType2,
BsmtFinSF2,
BsmtUnfSF,
TotalBsmtSF,
Heating,
HeatingQC,
CentralAir,
Electrical,
FirstFlrSF,
SecondFlrSF,
LowQualFinSF,
GrLivArea,
BsmtFullBath,
BsmtHalfBath,
FullBath,
HalfBath,
BedroomAbvGr,
KitchenAbvGr,
KitchenQual,
TotRmsAbvGrd,
Functional,
Fireplaces,
FireplaceQu,
GarageType,
GarageYrBlt,
GarageFinish,
GarageCars,
GarageArea,
GarageQual,
GarageCond,
PavedDrive,
WoodDeckSF,
OpenPorchSF,
EnclosedPorch,
ThirdSsnPorch,
ScreenPorch,
PoolArea,
PoolQC,
Fence,
MiscFeature,
MiscVal,
MoSold,
YrSold,
SaleType,
SaleCondition)
	




data = line.map(parseLines)


schema1 = StructType([StructField('Id', StringType(), True), 
StructField('MSSubClass', StringType(), True), 
StructField('MSZoning', StringType(), True), 
StructField('LotFrontage', StringType(), True), 
StructField('LotArea', StringType(), True), 
StructField('Street', StringType(), True), 
StructField('Alley', StringType(), True), 
StructField('LotShape', StringType(), True), 
StructField('LandContour', StringType(), True), 
StructField('Utilities', StringType(), True), 
StructField('LotConfig', StringType(), True), 
StructField('LandSlope', StringType(), True), 
StructField('Neighborhood', StringType(), True), 
StructField('Condition1', StringType(), True), 
StructField('Condition2', StringType(), True), 
StructField('BldgType', StringType(), True), 
StructField('HouseStyle', StringType(), True), 
StructField('OverallQual', StringType(), True), 
StructField('OverallCond', StringType(), True), 
StructField('YearBuilt', StringType(), True), 
StructField('YearRemodAdd', StringType(), True), 
StructField('RoofStyle', StringType(), True), 
StructField('RoofMatl', StringType(), True), 
StructField('Exterior1st', StringType(), True), 
StructField('Exterior2nd', StringType(), True), 
StructField('MasVnrType', StringType(), True), 
StructField('MasVnrArea', StringType(), True), 
StructField('ExterQual', StringType(), True), 
StructField('ExterCond', StringType(), True), 
StructField('Foundation', StringType(), True), 
StructField('BsmtQual', StringType(), True), 
StructField('BsmtCond', StringType(), True), 
StructField('BsmtExposure', StringType(), True), 
StructField('BsmtFinType1', StringType(), True), 
StructField('BsmtFinSF1', StringType(), True), 
StructField('BsmtFinType2', StringType(), True), 
StructField('BsmtFinSF2', StringType(), True), 
StructField('BsmtUnfSF', StringType(), True), 
StructField('TotalBsmtSF', StringType(), True), 
StructField('Heating', StringType(), True), 
StructField('HeatingQC', StringType(), True), 
StructField('CentralAir', StringType(), True), 
StructField('Electrical', StringType(), True), 
StructField('1stFlrSF', StringType(), True), 
StructField('2ndFlrSF', StringType(), True), 
StructField('LowQualFinSF', StringType(), True), 
StructField('GrLivArea', StringType(), True), 
StructField('BsmtFullBath', StringType(), True), 
StructField('BsmtHalfBath', StringType(), True), 
StructField('FullBath', StringType(), True), 
StructField('HalfBath', StringType(), True), 
StructField('BedroomAbvGr', StringType(), True), 
StructField('KitchenAbvGr', StringType(), True), 
StructField('KitchenQual', StringType(), True), 
StructField('TotRmsAbvGrd', StringType(), True), 
StructField('Functional', StringType(), True), 
StructField('Fireplaces', StringType(), True), 
StructField('FireplaceQu', StringType(), True), 
StructField('GarageType', StringType(), True), 
StructField('GarageYrBlt', StringType(), True), 
StructField('GarageFinish', StringType(), True), 
StructField('GarageCars', StringType(), True), 
StructField('GarageArea', StringType(), True), 
StructField('GarageQual', StringType(), True), 
StructField('GarageCond', StringType(), True), 
StructField('PavedDrive', StringType(), True), 
StructField('WoodDeckSF', StringType(), True), 
StructField('OpenPorchSF', StringType(), True), 
StructField('EnclosedPorch', StringType(), True), 
StructField('3SsnPorch', StringType(), True), 
StructField('ScreenPorch', StringType(), True), 
StructField('PoolArea', StringType(), True), 
StructField('PoolQC', StringType(), True), 
StructField('Fence', StringType(), True), 
StructField('MiscFeature', StringType(), True), 
StructField('MiscVal', StringType(), True), 
StructField('MoSold', StringType(), True), 
StructField('YrSold', StringType(), True), 
StructField('SaleType', StringType(), True), 
StructField('SaleCondition', StringType(), True)])



df = sqlContext.createDataFrame(data, schema1)
df.write.save("json_iowa_houses", format="json")



 