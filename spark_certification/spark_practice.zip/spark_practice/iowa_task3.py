## querying the hive tables, apply aggregate functionalities, conditions and ordering.
# write to hdfs in parquet file 

# cannot connect to hive. this is fake data
# select average sales, average employees in given counties. order by highest average sales


from pyspark import SparkContext, SparkConf
conf = SparkConf().setMaster("local").setAppName("task3")
sc = SparkContext(conf=conf)
from pyspark.sql import HiveContext
sqlContext = HiveContext(sc)
from pyspark.sql.types import *

answer = sqlContext.sql("select avg(sales), avg(employees), county    \
from iowa_houses   \
group by county   \
order by avg(sales) ")



answer.rdd.map(lambda x: "\t".join(map(str,x))).coalesce(1).saveAsTextFile("file:///spark_practice/solutions/task3")